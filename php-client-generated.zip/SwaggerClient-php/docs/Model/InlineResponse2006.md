# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Descriptive name or purpose of the data stream | [optional] 
**destination** | [**\Swagger\Client\Model\Apiv2dataStreamDestination**](Apiv2dataStreamDestination.md) |  | [optional] 
**filters** | [**\Swagger\Client\Model\Apiv2dataStreamFilters[]**](Apiv2dataStreamFilters.md) |  | [optional] 
**data_stream_type** | [****](.md) |  | [optional] 
**relation_resolution** | [****](.md) |  | [optional] 
**status** | [****](.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

