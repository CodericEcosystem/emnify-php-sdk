# GetOrganisationActiveTariffPlanResponseTariffPlanRuntime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_units** | **float** |  | [optional] 
**time_unit_id** | **float** |  | [optional] 
**id** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

