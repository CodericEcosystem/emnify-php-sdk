# RetrieveAvailableServicesresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**description** | **string** |  | [optional] 
**teleservice_code** | **int** |  | [optional] 
**used_with_vlr** | **bool** |  | [optional] 
**used_with_sgsn** | **bool** |  | [optional] 
**traffic_type** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

