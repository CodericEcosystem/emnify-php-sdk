# ESIMInstallationCodeInJSONFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iccid** | **string** | ICCID of the selected SIM | [optional] 
**payload** | **string** | Installation code of the selected SIM | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

