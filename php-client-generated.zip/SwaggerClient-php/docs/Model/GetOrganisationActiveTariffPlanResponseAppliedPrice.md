# GetOrganisationActiveTariffPlanResponseAppliedPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sim_activated_rate** | [**\Swagger\Client\Model\GetOrganisationActiveTariffPlanResponseAppliedPriceSimActivatedRate[]**](GetOrganisationActiveTariffPlanResponseAppliedPriceSimActivatedRate.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

