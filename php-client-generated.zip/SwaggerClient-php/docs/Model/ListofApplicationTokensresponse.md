# ListofApplicationTokensresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**description** | **string** |  | [optional] 
**created** | **string** |  | [optional] 
**status** | **object** |  | [optional] 
**expiry_date** | **string** |  | [optional] 
**ip** | **string** |  | [optional] 
**creator** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

