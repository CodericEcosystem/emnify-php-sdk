# GetMonthlyOrganisationStatsResponseInclusiveVolume

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unpooled** | **float** | Total cost of all unpooled inclusive volumes | [optional] 
**pooled** | **float** | Total cost of all pooled inclusive volumes | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

