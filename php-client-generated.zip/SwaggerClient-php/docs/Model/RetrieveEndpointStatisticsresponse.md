# RetrieveEndpointStatisticsresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_month** | **object** |  | [optional] 
**current_month** | **object** |  | [optional] 
**last_hour** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

