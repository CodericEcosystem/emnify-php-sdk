# GetMonthlyOrganisationStatsResponseSim

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issued** | **float** |  | [optional] 
**factory_mode** | **float** |  | [optional] 
**active** | **float** |  | [optional] 
**suspended** | **float** |  | [optional] 
**total** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

