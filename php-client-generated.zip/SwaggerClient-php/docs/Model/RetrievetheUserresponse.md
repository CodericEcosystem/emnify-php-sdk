# RetrievetheUserresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**username** | **string** |  | [optional] 
**name** | **string** |  | [optional] 
**created** | **string** |  | [optional] 
**status** | **object** |  | [optional] 
**organisation** | **object** |  | [optional] 
**roles** | **object[]** |  | [optional] 
**mfa** | **object[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

