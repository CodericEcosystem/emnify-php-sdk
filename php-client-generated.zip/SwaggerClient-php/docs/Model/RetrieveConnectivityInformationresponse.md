# RetrieveConnectivityInformationresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ussd_info** | **object** |  | [optional] 
**subscriber_info** | **object** |  | [optional] 
**request_timestamp** | **string** |  | [optional] 
**reply_timestamp** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

