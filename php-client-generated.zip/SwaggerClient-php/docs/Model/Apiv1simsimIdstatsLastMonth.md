# Apiv1simsimIdstatsLastMonth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**\Swagger\Client\Model\Apiv1simsimIdstatsLastMonthData**](Apiv1simsimIdstatsLastMonthData.md) |  | [optional] 
**sms** | [**\Swagger\Client\Model\Apiv1simsimIdstatsLastMonthData**](Apiv1simsimIdstatsLastMonthData.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

