# Apiv1simsimIdstatsLastMonthData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sim_id** | **float** |  | [optional] 
**month** | [**\DateTime**](\DateTime.md) |  | [optional] 
**volume** | **float** |  | [optional] 
**volume_tx** | **float** |  | [optional] 
**volume_rx** | **float** |  | [optional] 
**traffic_type_id** | **float** |  | [optional] 
**last_updated** | [**\DateTime**](\DateTime.md) |  | [optional] 
**cost** | **float** |  | [optional] 
**currency_id** | **float** |  | [optional] 
**id** | **float** |  | [optional] 
**traffic_type** | [**\Swagger\Client\Model\OrganisationDailyTrafficObjectTrafficType**](OrganisationDailyTrafficObjectTrafficType.md) |  | [optional] 
**currency** | [**\Swagger\Client\Model\Currency**](Currency.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

