# Apiv1organisationorgIdtariffPlanTariffPlanPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sim_activated_rate** | [**\Swagger\Client\Model\OneOfapiv1organisationorgIdtariffPlanTariffPlanPriceSimActivatedRateItems[]**](.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

