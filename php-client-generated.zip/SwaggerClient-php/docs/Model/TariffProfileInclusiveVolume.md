# TariffProfileInclusiveVolume

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | [optional] 
**volume** | **float** |  | [optional] 
**rate** | **float** |  | [optional] 
**pooled** | **bool** |  | [optional] 
**start_date** | **string** |  | [optional] 
**end_date** | **string** |  | [optional] 
**ratezone** | [**\Swagger\Client\Model\TariffProfileInclusiveVolumeRatezone**](TariffProfileInclusiveVolumeRatezone.md) |  | [optional] 
**currency** | [**\Swagger\Client\Model\TariffProfileInclusiveVolumeCurrency**](TariffProfileInclusiveVolumeCurrency.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

