# GetHourlyOrganisationStatsResponseData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rx** | **string[]** | Downloaded data - Array index &#x60;0&#x60;: Time as &#x60;HH:mm&#x60; string, index &#x60;1&#x60;: consumed volume | [optional] 
**tx** | **string[]** | Uploaded data - Array index &#x60;0&#x60;: Time as &#x60;HH:mm&#x60; string, index &#x60;1&#x60;: consumed volume | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

