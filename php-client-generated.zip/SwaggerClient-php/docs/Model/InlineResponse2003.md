# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**volume** | **int** |  | [optional] 
**period** | [**\Swagger\Client\Model\Apiv1serviceserviceIdtrafficLimitPeriod**](Apiv1serviceserviceIdtrafficLimitPeriod.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

