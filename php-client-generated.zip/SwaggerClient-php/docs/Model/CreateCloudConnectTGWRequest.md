# CreateCloudConnectTGWRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **int** |  | 
**name** | **string** |  | 
**description** | **string** |  | [optional] 
**vpc_cidr** | **string[]** |  | 
**region** | **string** | the region that this attachment should be established to | 
**aws_account_id** | **string** | 12-digit identifier of the own AWS Account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

