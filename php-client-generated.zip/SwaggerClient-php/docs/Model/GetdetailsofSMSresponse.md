# GetdetailsofSMSresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**submit_date** | **string** |  | [optional] 
**delivery_date** | **string** |  | [optional] 
**expiry_date** | **string** |  | [optional] 
**final_date** | **string** |  | [optional] 
**retry_date** | **string** |  | [optional] 
**last_delivery_attempt** | **string** |  | [optional] 
**retry_count** | **string** |  | [optional] 
**gsm_map_error** | **string** |  | [optional] 
**dcs** | **int** |  | [optional] 
**pid** | **int** |  | [optional] 
**source_address** | **string** |  | [optional] 
**endpoint** | **object** |  | [optional] 
**sim_id** | **string** |  | [optional] 
**iccid** | **string** |  | [optional] 
**msisdn** | **string** |  | [optional] 
**imsi** | **string** |  | [optional] 
**msc** | **string** |  | [optional] 
**udh** | **string** |  | [optional] 
**payload** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**status** | **object** |  | [optional] 
**sms_type** | **object** |  | [optional] 
**source_address_type** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

