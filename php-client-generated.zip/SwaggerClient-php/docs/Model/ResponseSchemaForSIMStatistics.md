# ResponseSchemaForSIMStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_month** | [**\Swagger\Client\Model\Apiv1simsimIdstatsLastMonth**](Apiv1simsimIdstatsLastMonth.md) |  | 
**current_month** | [**\Swagger\Client\Model\Apiv1simsimIdstatsLastMonth**](Apiv1simsimIdstatsLastMonth.md) |  | 
**last_hour** | [**\Swagger\Client\Model\Apiv1simsimIdstatsLastMonth**](Apiv1simsimIdstatsLastMonth.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

