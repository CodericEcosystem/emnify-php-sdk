# TariffProfile1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | [optional] 
**name** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**used_count** | **string** |  | [optional] 
**organisation_id** | **string** |  | [optional] 
**tariff** | [**\Swagger\Client\Model\Apiv1tariffProfileTariff**](Apiv1tariffProfileTariff.md) |  | [optional] 
**inclusive_volume** | [**\Swagger\Client\Model\TariffProfileInclusiveVolume**](TariffProfileInclusiveVolume.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

