# EndpointRuntimeData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msc** | **string** |  | [optional] 
**sgsn** | **string** |  | [optional] 
**sgsn_ip_address** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

