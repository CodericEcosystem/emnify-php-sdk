# RetrieveaSingleServiceProfileresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**allowed_3g** | **bool** |  | [optional] 
**allowed_4g** | **bool** |  | [optional] 
**allowed_nb_iot** | **bool** |  | [optional] 
**apply_sms_quota** | **bool** |  | [optional] 
**apply_data_quota** | **bool** |  | [optional] 
**retail** | **bool** |  | [optional] 
**sms_p2p_int** | **bool** |  | [optional] 
**sms_p2p_ext** | **bool** |  | [optional] 
**prepaid** | **bool** |  | [optional] 
**nipdp** | **bool** |  | [optional] 
**used_count** | **int** |  | [optional] 
**api_callback** | **object** |  | [optional] 
**api_secret** | **object** |  | [optional] 
**moc_callback** | **object** |  | [optional] 
**esme_interface_type** | **object** |  | [optional] 
**breakout_region** | **object** |  | [optional] 
**service** | **object[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

