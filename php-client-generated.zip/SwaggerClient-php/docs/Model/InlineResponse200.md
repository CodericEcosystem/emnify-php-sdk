# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**organisation_type_id** | **string** |  | [optional] 
**country_id** | **string** |  | [optional] 
**organisation_status_id** | **string** |  | [optional] 
**ext_reference** | **string** |  | [optional] 
**monthly_cost_limit** | **string** |  | [optional] 
**currency_id** | **int** |  | [optional] 
**organisation_class_id** | **int** |  | [optional] 
**created** | [**\DateTime**](\DateTime.md) |  | [optional] 
**verification_type_id** | **string** |  | [optional] 
**verification** | **string** |  | [optional] 
**brand_id** | **string** |  | [optional] 
**default_sms_routing_id** | **string** |  | [optional] 
**id** | **int** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

