# RetrieveEventsresponse4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**alert** | **bool** |  | 
**description** | **string** |  | 
**timestamp** | **string** |  | 
**event_type** | **object** |  | 
**event_source** | **object** |  | 
**event_severity** | **object** |  | 
**organisation** | **object** |  | 
**user** | **object** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

