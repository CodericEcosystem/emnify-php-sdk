# UpdateSIM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer_org** | [**\Swagger\Client\Model\HasId**](HasId.md) |  | 
**reseller_org** | [**\Swagger\Client\Model\HasId**](HasId.md) |  | 
**customer_org** | [**\Swagger\Client\Model\HasId**](HasId.md) |  | 
**status** | [**\Swagger\Client\Model\Status**](Status.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

