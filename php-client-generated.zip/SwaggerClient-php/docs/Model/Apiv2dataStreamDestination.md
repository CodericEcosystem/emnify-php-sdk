# Apiv2dataStreamDestination

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connection_type** | **string** |  | 
**format** | **string** |  | [optional] 
**credentials** | [**OneOfapiv2dataStreamDestinationCredentials**](OneOfapiv2dataStreamDestinationCredentials.md) | Destination credentials | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

