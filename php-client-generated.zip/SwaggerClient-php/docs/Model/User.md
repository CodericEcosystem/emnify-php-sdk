# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**username** | **string** |  | [optional] 
**name** | **string** |  | [optional] 
**created** | **string** |  | [optional] 
**status** | [**\Swagger\Client\Model\Apiv1userStatus**](Apiv1userStatus.md) |  | [optional] 
**organisation** | [**\Swagger\Client\Model\Apiv1eventOrganisation**](Apiv1eventOrganisation.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

