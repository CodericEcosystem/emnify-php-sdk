# RetrieveEventsresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **string** |  | [optional] 
**alert** | **bool** |  | [optional] 
**description** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**event_type** | **object** |  | [optional] 
**event_source** | **object** |  | [optional] 
**event_severity** | **object** |  | [optional] 
**organisation** | **object** |  | [optional] 
**endpoint** | **object** |  | [optional] 
**sim** | **object** |  | [optional] 
**imsi** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

