# RetrieveEndpointConnectivityStatusresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **object** |  | [optional] 
**location** | **object** |  | [optional] 
**pdp_context** | **object** |  | [optional] 
**services** | **string[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

