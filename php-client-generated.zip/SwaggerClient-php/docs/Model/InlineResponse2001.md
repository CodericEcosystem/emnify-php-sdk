# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **string** | Date in &#x60;YYYY-MM-DD&#x60; format or &#x60;TOTAL&#x60; to indicate the total volume and cost of the traffic type | [optional] 
**data** | [**\Swagger\Client\Model\OrganisationDailyTrafficObject**](OrganisationDailyTrafficObject.md) |  | [optional] 
**sms** | [**\Swagger\Client\Model\OrganisationDailyTrafficObject**](OrganisationDailyTrafficObject.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

