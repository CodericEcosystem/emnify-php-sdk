# InlineResponse20011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attachment_region** | **string** | The region the customer&#x27;s attachment will reside in | [optional] 
**device_breakout_region** | **string** | The region the traffic will be peered to | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

